package cl.duoc.doggyspa.repository;
import cl.duoc.doggyspa.model.Mascota;
import org.springframework.data.jpa.repository.JpaRepository;
public interface MascotaRepository extends JpaRepository<Mascota,Long> {}
