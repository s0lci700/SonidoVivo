package cl.duoc.doggyspa.controller;
import cl.duoc.doggyspa.repository.UsuarioRepository;
import cl.duoc.doggyspa.security.JwtService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.*;
import org.springframework.security.authentication.*;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/auth") public class AuthController {
 private final AuthenticationManager auth;private final UsuarioRepository repo;private final JwtService jwt;
 public AuthController(AuthenticationManager a,UsuarioRepository r,JwtService j){auth=a;repo=r;jwt=j;}
 public record Login(@NotBlank String username,@NotBlank String password){}
 public record Token(String token,String rol,String tipo){}
 @PostMapping("/login") public ResponseEntity<Token> login(@RequestBody Login req){
  auth.authenticate(new UsernamePasswordAuthenticationToken(req.username(),req.password()));
  var u=repo.findByUsername(req.username()).orElseThrow();return ResponseEntity.ok(new Token(jwt.crear(u),u.getRol().name(),"Bearer"));
 }
}
