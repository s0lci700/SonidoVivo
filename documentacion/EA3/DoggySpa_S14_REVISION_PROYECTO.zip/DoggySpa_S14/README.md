# 🐾 DoggySpa S14 — edición revisada para EP3 (2026-2)

Continuación técnica del ZIP DoggySpa S14 previamente generado, incorporando correcciones observadas en laboratorio el 9/11/2026. **No es el ZIP original de la semana 13.**

## Requisitos
- Windows 11, JDK 21, Maven, Node.js y VS Code.
- UNA base de datos: XAMPP/MariaDB o Docker/MySQL (no ambas en puerto 3306).

## Paso 1 — Base de datos
**XAMPP:** encender MySQL, phpMyAdmin > SQL y ejecutar `infra/mysql/xampp/crear_bd.sql` con permisos administrativos. Si ya existe, comprobar permisos. Error Aria #1030/176: no reparar a ciegas, respaldar y revisar logs.
**Docker:** desde `infra/mysql`: `docker compose up -d`, luego `docker compose ps`. Detener MySQL de XAMPP antes. No ejecutar `docker compose down -v` si se quieren preservar datos.

## Paso 2 — Backend
Abrir `backend` en VS Code. Verificar `java -version`, `javac -version`, `mvn -version` (Java 21). Iniciar con `mvn clean spring-boot:run` **o** ejecutar la clase principal con Java 21. Confirmar `HikariPool-1 - Start completed` y `Started DoggySpaApplication`.
Swagger: http://localhost:8080/swagger-ui.html ; API docs: http://localhost:8080/v3/api-docs . Swagger debe mostrar `Authorize`.

## Paso 3 — Frontend
Abrir `frontend`, ejecutar `npm install` y `npm run dev`; abrir http://localhost:5173 . La sesión React se almacena solo en memoria, NO persiste tras recargar (tema de semana 15).

## Usuarios (solo laboratorio)
- `admin` / `Admin123!` → `ADMIN`, consulta y modificación.
- `usuario` / `Usuario123!` → `USER`, solo lectura.
- Cambiar contraseñas y JWT_SECRET para cualquier uso real; nunca publicar claves ni tokens.

## Pruebas en Swagger
1. POST `/auth/login` con `usuario`; copiar solo el campo `token`.
2. Autorizar en `Authorize` (solo el token, sin prefijo Bearer).
3. GET `/api/mascotas` → 200; POST `/api/mascotas` con USER → 403.
4. Logout en Authorize; POST sin token → 401.
5. POST `/auth/login` como `admin`, reemplazar token; POST con ADMIN → 201 (JSON: `nombre`, `especie`, `edad`, `clienteId`, usando cliente válido).
6. Token vencido/incorrecto en ruta protegida → 401.

## Pruebas automatizadas
`cd backend` y `mvn test` ejecuta pruebas MockMvc de integración de cadena de filtros (token simulado), sin MySQL: casos 401, 200, 403 y 201. Estas pruebas no verifican criptografía JWT real ni conexión DB; realizar también pruebas manuales descritas.

## Criterios y alcance
- Backend Spring Boot 3.3.5/JDK21; JWT + roles; JPA/MySQL; Swagger; React.
- Se incluyen base y avances S14; no entrega una solución universal a los proyectos de cada grupo.
- EP3: encargo grupal 40% y defensa individual 60%; entrega segunda sesión semana 16; defensa primera sesión semana 17.
- Semana 15: persistencia de sesión, rutas protegidas React, expiración y logout.

## Diagnóstico rápido
- `UnsupportedClassVersionError 65 vs 61`: ejecución con Java 17; JDK 21 requerido.
- `Communications link failure`: MySQL/host/puerto inaccesibles.
- `Access denied 1044`: permisos de BD. Verificar script y SHOW GRANTS; no implica caída de MySQL.
- `Aria checksum 1030/176`: posible daño de tabla MariaDB; respaldar y consultar logs, no borrar `mysql/data`.
- Swagger sin botón Authorize: verificar OpenApiConfig, reiniciar backend y recargar Ctrl+F5.
- 401 con USER donde se espera 403: comprobar Bearer, token nuevo y registro único JwtFilter en cadena de Spring Security.
