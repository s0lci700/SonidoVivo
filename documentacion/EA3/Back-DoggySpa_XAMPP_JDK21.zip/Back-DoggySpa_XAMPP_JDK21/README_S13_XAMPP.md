# DoggySpa: semana 13 – MySQL de XAMPP

**Se parte de `DoggySpa_Desde_Demo_Oficial_JDK21.zip`, cuyo CRUD React y Spring Boot ya fue probado por el docente.** No se modificaron las cinco clases Java ni el frontend.

## 1. Verificar JDK y Maven (Windows PowerShell)
```powershell
java -version
mvn -version
```
Maven debe utilizar JDK 21. Abrir VS Code en la carpeta que contiene `pom.xml`.

## 2. Comprobar la versión de referencia H2
```powershell
mvn -s .\settings-google.xml spring-boot:run
```
Abrir http://localhost:8080/api/mascotas y detener con Ctrl+C.

## 3. Preparar XAMPP
- Iniciar el módulo MySQL de XAMPP (MariaDB). Confirmar puerto 3306 en el panel.
- Para usar phpMyAdmin, iniciar además Apache en el panel y entrar a http://localhost/phpmyadmin.
- Crear la BD `doggyspa` con el script `sql/01_crear_doggyspa.sql`.
- Este script no importa datos desde H2: la nueva base empieza vacía.

## 4. Iniciar Spring Boot con MariaDB
```powershell
mvn -s .\settings-google.xml "-Dspring-boot.run.profiles=mysql" spring-boot:run
```
El usuario predeterminado es `root` y contraseña vacía, solo si XAMPP local está configurado así. Si tiene contraseña, en la terminal actual: `$env:DB_PASSWORD = 'TU_CLAVE_LOCAL'` (no subirla a Git).

## 5. Validar desde React y phpMyAdmin
- Ejecutar frontend (`npm install` la primera vez; después `npm run dev`).
- Crear mascota, listar, editar y consultar la tabla `mascota` desde phpMyAdmin.
- Detener únicamente Spring Boot y reiniciarlo: la mascota debe conservarse.
- Si cambia de H2 a MariaDB, **no** se migran registros automáticamente.

## Diagnóstico
- `Connection refused`: servidor XAMPP apagado o puerto incorrecto.
- `Access denied`: usuario o contraseña de XAMPP distintos de los configurados.
- `Unknown database 'doggyspa'`: falta ejecutar SQL de creación.
- `ClassNotFoundException org.mariadb.jdbc.Driver`: verificar que la dependencia org.mariadb.jdbc:mariadb-java-client esté en pom.xml y que se haya descargado.
- Error HTTP 429 de Maven Central: se provee `settings-google.xml` y debe pasarse con `-s`.
- `Port 8080 was already in use`: cerrar instancia Spring Boot anterior.

## Notas
XAMPP usa MariaDB, aunque su módulo se denomina MySQL. El driver MariaDB figura en las dependencias runtime estándar; H2 continúa disponible como perfil predeterminado. No ejecutar Docker en esta sesión.
