# DoggySpa sobre el `demo.zip` oficial del docente

Este proyecto conserva **exactamente el pom.xml, Maven Wrapper y versiones de dependencias** del `demo.zip` generado por el docente mediante Spring Initializr. Se agregaron solo las cuatro clases de DoggySpa y la configuración de H2 para continuar con React.

## Requisitos
- **JDK 21** (Java 21 en laboratorio).
- Maven 3.10 instalado, o el script Wrapper oficial si puede descargar su distribución.
- VS Code con extensiones de Java y Spring Boot.

## En Windows (PowerShell)

```powershell
java -version
mvn -version
mvn spring-boot:run
```

En **ambos** primeros comandos debe figurar Java 21. Si Maven muestra Java 17 aunque Java 21 esté instalado, debe seleccionarse el JDK 21 en `JAVA_HOME` y reabrir la terminal. No cambies `pom.xml` a 17.

Comprobar en navegador:
- http://localhost:8080/api/mascotas
- http://localhost:8080/swagger-ui/index.html

Luego ejecutar **el frontend React DoggySpa ya validado**, desde su propia terminal:

```powershell
npm install
npm run dev
```

Frontend: http://localhost:5173. Los endpoints originales se mantienen sin cambios: `GET/POST /api/mascotas` y `GET/PUT/DELETE /api/mascotas/{id}`. El controlador admite CORS desde http://localhost:5173.

### Sobre HTTP 429
Si Maven Central responde `429`, **la generación con Spring Initializr no elimina el bloqueo de red**. Maven necesita descargar artefactos todavía ausentes en la caché. No insistir con ejecuciones repetidas ni borrar `.m2`. Si las dependencias ya están almacenadas localmente puede probarse `mvn -o spring-boot:run`. Esta copia **no garantiza** ejecución mientras persista el bloqueo.

### Alcance
- Esta copia sigue **H2**, todavía no MySQL/XAMPP ni Docker.
- H2 se configura en memoria; se pierden registros tras reiniciar.
- No incluye cambios de Spring Security/JWT, previstos para semanas posteriores.
- Proyecto generado a partir de fuentes; la compilación real depende de tener disponibles las dependencias Maven.
