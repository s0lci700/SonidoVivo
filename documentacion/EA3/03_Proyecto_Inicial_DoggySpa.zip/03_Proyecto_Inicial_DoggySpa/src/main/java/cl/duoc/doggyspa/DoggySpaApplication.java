package cl.duoc.doggyspa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoggySpaApplication {
    public static void main(String[] args) {
        SpringApplication.run(DoggySpaApplication.class, args);
    }
}
