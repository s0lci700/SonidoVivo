# DoggySpa — proyecto inicial | DSY1104 semana 12

## Objetivo
Completar, paso a paso, una API REST de mascotas con Spring Boot 4.1.1 y Java 21.

## Requisitos
- JDK 21 (`java -version`).
- Internet en la primera compilación para descargar dependencias y el Maven Wrapper.
- IntelliJ IDEA o VS Code con soporte Java.

## Ejecución en Windows
Desde esta carpeta en PowerShell: `./mvnw.cmd spring-boot:run`.
En CMD: `mvnw.cmd spring-boot:run`.
En Linux/macOS: `./mvnw spring-boot:run`.

En el proyecto inicial no hay controladores, de modo que `http://localhost:8080/api/mascotas` devolverá 404. Es NORMAL hasta completar el taller.

## Actividad guiada
Implementar `model/Mascota.java`, `repository/MascotaRepository.java`, `service/MascotaService.java`, `controller/MascotaController.java` y probar Swagger en `http://localhost:8080/swagger-ui.html`.

## Observación
No incluye código de solución de las capas. No depende de AWS ni de una base de datos externa.
