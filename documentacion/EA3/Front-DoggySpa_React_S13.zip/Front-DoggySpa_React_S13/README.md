# DoggySpa React modular (semana 13)

Frontend probado anteriormente con DoggySpa; se conserva la lógica y sólo se alinea el host Vite a `http://localhost:5173` para coincidir con CORS.

1. Backend: en la raíz `DoggySpa_Backend_S13_JDK21`, ejecuta `mvn -s .\settings-google.xml spring-boot:run` para H2, o el comando MySQL de su README.
2. Comprueba http://localhost:8080/api/mascotas (JSON).
3. En esta carpeta: `npm install`; después `npm run dev`.
4. Abre **http://localhost:5173** y registra una mascota.

Estructura: `src/components`, `src/hooks/useMascotas.js`, `src/services/mascotasApi.js`, `src/constants`, `src/styles`.

No ejecuta npm desde la raíz del backend. En Docker sólo se contenedoriza la base de datos; frontend/backend permanecen en VS Code durante semana 13.
