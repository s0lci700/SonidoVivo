export const MASCOTA_VACIA = { nombre: '', especie: 'Perro', raza: '', edad: '', nombreDueno: '' };
export function prepararMascota(form) {
  const mascota = {
    nombre: form.nombre.trim(), especie: form.especie.trim(), raza: form.raza.trim(),
    edad: Number(form.edad), nombreDueno: form.nombreDueno.trim()
  };
  if (!Number.isInteger(mascota.edad) || mascota.edad < 0 || mascota.edad > 40) {
    throw new Error('La edad debe ser un entero entre 0 y 40.');
  }
  return mascota;
}
