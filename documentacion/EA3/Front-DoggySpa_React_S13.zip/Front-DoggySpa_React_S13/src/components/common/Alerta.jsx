export default function Alerta({ feedback, onCerrar }) {
  if (!feedback) return null;
  return <div role="alert" className={`alert ${feedback.type}`}>
    {feedback.text}
    <button type="button" aria-label="Cerrar aviso" onClick={onCerrar}>×</button>
  </div>;
}
