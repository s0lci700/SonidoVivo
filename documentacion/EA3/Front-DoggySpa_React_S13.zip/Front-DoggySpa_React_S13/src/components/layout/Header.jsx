export default function Header() {
  return <header className="hero">
    <div className="brand">🐾 DoggySpa <span>LABORATORIO FULL STACK</span></div>
    <h1>Gestión de mascotas</h1>
    <p>Frontend React + Vite consumiendo una API REST de Spring Boot</p>
    <div className="pills"><span>React · :5173</span><span>REST / JSON</span><span>Spring Boot · :8080</span></div>
  </header>;
}
