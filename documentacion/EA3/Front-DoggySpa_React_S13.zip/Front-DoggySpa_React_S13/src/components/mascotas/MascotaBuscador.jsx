import { useState } from 'react';
export default function MascotaBuscador({ onConsultar, onError }) {
  const [id, setId] = useState('');
  const [resultado, setResultado] = useState(null);
  const [buscando, setBuscando] = useState(false);
  async function buscar(event) {
    event.preventDefault();
    setResultado(null);
    if (!/^\d+$/.test(id) || Number(id) < 1) {
      onError('Ingresa un ID entero positivo.'); return;
    }
    setBuscando(true);
    try { setResultado(await onConsultar(id)); }
    catch (error) { onError(`Consulta ID ${id}: ${error.message}`); }
    finally { setBuscando(false); }
  }
  return <div><hr /><h3>Buscar por ID</h3>
    <p className="subtitle">GET /api/mascotas/{'{id}'} · prueba un ID inexistente (ej.: 999)</p>
    <form className="lookup" onSubmit={buscar}>
      <input aria-label="ID de mascota" type="number" min="1" step="1" placeholder="ID: 1 o 999" value={id} onChange={e => setId(e.target.value)} />
      <button className="primary" disabled={buscando}>{buscando ? 'Consultando…' : 'Consultar'}</button>
    </form>
    {resultado && <pre>{JSON.stringify(resultado, null, 2)}</pre>}
  </div>;
}
