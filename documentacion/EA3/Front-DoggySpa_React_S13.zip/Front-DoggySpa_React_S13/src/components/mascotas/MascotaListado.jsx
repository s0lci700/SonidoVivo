import MascotaCard from './MascotaCard.jsx';
import MascotaBuscador from './MascotaBuscador.jsx';
export default function MascotaListado({ mascotas, loading, busy, onActualizar, onEditar, onEliminar, onConsultar, onError }) {
  return <section className="panel">
    <div className="section-head"><div><h2>Listado de mascotas</h2><p className="subtitle">GET /api/mascotas</p></div>
      <button className="secondary" disabled={loading} onClick={onActualizar}>↻ Actualizar</button></div>
    {loading ? <p>Cargando desde Spring Boot…</p> : mascotas.length === 0 ?
      <div className="empty">No hay mascotas registradas. Usa el formulario para crear la primera.</div> :
      <div className="cards">{mascotas.map(mascota => <MascotaCard key={mascota.id} mascota={mascota} busy={busy} onEditar={onEditar} onEliminar={onEliminar} />)}</div>}
    <MascotaBuscador onConsultar={onConsultar} onError={onError} />
  </section>;
}
