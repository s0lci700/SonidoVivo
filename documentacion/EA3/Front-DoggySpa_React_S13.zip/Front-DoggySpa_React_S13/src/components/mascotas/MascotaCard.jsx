export default function MascotaCard({ mascota, busy, onEditar, onEliminar }) {
  return <article className="pet">
    <div><span className="pet-icon">{mascota.especie?.toLowerCase() === 'gato' ? '🐈' : '🐕'}</span>
      <div><h3>{mascota.nombre} <span className="id">#{mascota.id}</span></h3>
        <p>{mascota.especie} · {mascota.raza} · {mascota.edad} año(s)</p>
        <small>Dueño/a: {mascota.nombreDueno}</small></div></div>
    <div className="pet-actions">
      <button className="secondary" disabled={busy} onClick={() => onEditar(mascota)}>Editar</button>
      <button className="danger" disabled={busy} onClick={() => onEliminar(mascota)}>Eliminar</button>
    </div>
  </article>;
}
