export default function MascotaFormulario({ form, setForm, editId, busy, onGuardar, onCancelar }) {
  const cambiar = event => setForm(anterior => ({ ...anterior, [event.target.name]: event.target.value }));
  return <section className="panel">
    <h2>{editId === null ? 'Registrar mascota' : `Editar mascota #${editId}`}</h2>
    <p className="subtitle">{editId === null ? 'POST /api/mascotas' : 'PUT /api/mascotas/{id}'}</p>
    <form className="form" onSubmit={onGuardar}>
      <label>Nombre<input name="nombre" required maxLength="100" value={form.nombre} onChange={cambiar} placeholder="Rocky" /></label>
      <label>Especie<select name="especie" value={form.especie} onChange={cambiar}><option>Perro</option><option>Gato</option><option>Otro</option></select></label>
      <label>Raza<input name="raza" required maxLength="100" value={form.raza} onChange={cambiar} placeholder="Labrador" /></label>
      <label>Edad<input name="edad" type="number" min="0" max="40" step="1" required value={form.edad} onChange={cambiar} placeholder="3" /></label>
      <label>Nombre del dueño<input name="nombreDueno" required maxLength="100" value={form.nombreDueno} onChange={cambiar} placeholder="Carlos Pérez" /></label>
      <div className="actions">
        <button className="primary" disabled={busy}>{busy ? 'Procesando…' : editId === null ? 'Registrar mascota' : 'Guardar cambios'}</button>
        {editId !== null && <button type="button" className="secondary" onClick={onCancelar}>Cancelar</button>}
      </div>
    </form>
  </section>;
}
