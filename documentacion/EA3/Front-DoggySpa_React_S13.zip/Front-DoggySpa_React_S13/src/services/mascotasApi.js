// URL del servidor Spring Boot. Vite lee las variables VITE_ al iniciar.
export const API_BASE = (import.meta.env.VITE_API_URL || 'http://localhost:8080').replace(/\/$/, '');
const endpoint = `${API_BASE}/api/mascotas`;

async function request(path = '', options = {}) {
  let response;
  try {
    response = await fetch(`${endpoint}${path}`, {
      headers: {'Content-Type':'application/json', ...options.headers},
      ...options
    });
  } catch {
    throw new Error('No fue posible conectar con Spring Boot. Verifica localhost:8080 y CORS.');
  }
  if (response.status === 204) return null;
  const contentType = response.headers.get('content-type') || '';
  const body = contentType.includes('application/json') ? await response.json() : await response.text();
  if (!response.ok) {
    const detail = typeof body === 'object' ? (body.detail || body.message || body.title) : body;
    throw new Error(`HTTP ${response.status}${detail ? ` · ${detail}` : ''}`);
  }
  return body;
}
export const mascotasApi = {
  listar: () => request(),
  buscar: id => request(`/${id}`),
  crear: mascota => request('', {method:'POST',body:JSON.stringify(mascota)}),
  actualizar: (id, mascota) => request(`/${id}`, {method:'PUT',body:JSON.stringify(mascota)}),
  eliminar: id => request(`/${id}`, {method:'DELETE'})
};
