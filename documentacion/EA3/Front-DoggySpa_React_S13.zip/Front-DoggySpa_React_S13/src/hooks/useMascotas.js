import { useCallback, useEffect, useState } from 'react';
import { mascotasApi } from '../services/mascotasApi.js';

// Centraliza las operaciones con el backend; los componentes solo muestran la interfaz.
export function useMascotas() {
  const [mascotas, setMascotas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState(null);

  const cargar = useCallback(async () => {
    setLoading(true);
    try { setMascotas(await mascotasApi.listar()); }
    catch (error) { setFeedback({ type: 'error', text: error.message }); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { cargar(); }, [cargar]);

  async function ejecutar(accion, mensaje) {
    setBusy(true);
    setFeedback(null);
    try {
      await accion();
      setFeedback({ type: 'ok', text: mensaje });
      await cargar();
      return true;
    } catch (error) {
      setFeedback({ type: 'error', text: error.message });
      return false;
    } finally { setBusy(false); }
  }

  const registrar = datos => ejecutar(() => mascotasApi.crear(datos), 'Mascota registrada (POST 201).');
  const actualizar = (id, datos) => ejecutar(() => mascotasApi.actualizar(id, datos), 'Mascota actualizada (PUT 200).');
  const eliminar = mascota => ejecutar(() => mascotasApi.eliminar(mascota.id), 'Mascota eliminada (DELETE 204).');
  const consultar = id => mascotasApi.buscar(id);

  return { mascotas, loading, busy, feedback, setFeedback, cargar, registrar, actualizar, eliminar, consultar };
}
