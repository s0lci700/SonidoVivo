import { useState } from 'react';
import Header from './components/layout/Header.jsx';
import Alerta from './components/common/Alerta.jsx';
import MascotaFormulario from './components/mascotas/MascotaFormulario.jsx';
import MascotaListado from './components/mascotas/MascotaListado.jsx';
import { useMascotas } from './hooks/useMascotas.js';
import { MASCOTA_VACIA, prepararMascota } from './constants/mascota.js';
import { API_BASE } from './services/mascotasApi.js';

export default function App() {
  const { mascotas, loading, busy, feedback, setFeedback, cargar, registrar, actualizar, eliminar, consultar } = useMascotas();
  const [form, setForm] = useState({ ...MASCOTA_VACIA });
  const [editId, setEditId] = useState(null);

  function cancelar() { setEditId(null); setForm({ ...MASCOTA_VACIA }); }
  function editar(mascota) {
    setEditId(mascota.id);
    setForm({ nombre: mascota.nombre, especie: mascota.especie, raza: mascota.raza, edad: String(mascota.edad), nombreDueno: mascota.nombreDueno });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  async function guardar(event) {
    event.preventDefault();
    try {
      const datos = prepararMascota(form);
      const ok = editId === null ? await registrar(datos) : await actualizar(editId, datos);
      if (ok) cancelar();
    } catch (error) { setFeedback({ type: 'error', text: error.message }); }
  }
  async function confirmarEliminacion(mascota) {
    if (!window.confirm(`¿Eliminar a ${mascota.nombre} (ID ${mascota.id})?`)) return;
    await eliminar(mascota);
  }
  return <div className="layout">
    <Header />
    <main>
      <section className="notice"><strong>API configurada:</strong> <code>{API_BASE}/api/mascotas</code>
        <p>Primero ejecuta Spring Boot. No se usan datos simulados ni localStorage.</p></section>
      <Alerta feedback={feedback} onCerrar={() => setFeedback(null)} />
      <div className="columns">
        <MascotaFormulario form={form} setForm={setForm} editId={editId} busy={busy} onGuardar={guardar} onCancelar={cancelar} />
        <MascotaListado mascotas={mascotas} loading={loading} busy={busy} onActualizar={cargar} onEditar={editar}
          onEliminar={confirmarEliminacion} onConsultar={consultar}
          onError={texto => setFeedback({ type: 'error', text: texto })} />
      </div>
      <footer>Laboratorio DSY1104 · Semana 13 · Ejemplo de integración React ↔ Spring Boot</footer>
    </main>
  </div>;
}
