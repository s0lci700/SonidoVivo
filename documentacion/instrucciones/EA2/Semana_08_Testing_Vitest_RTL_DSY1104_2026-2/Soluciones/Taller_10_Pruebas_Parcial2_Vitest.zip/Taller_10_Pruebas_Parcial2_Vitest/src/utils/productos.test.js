import { describe,it,expect } from 'vitest';
import { filtrarProductos,calcularTotal } from './productos.js';

describe('utilidades de productos',()=>{
  const datos=[{id:1,nombre:'Mouse',precio:1000},{id:2,nombre:'Teclado',precio:2000}];
  it('filtra sin distinguir mayúsculas',()=>expect(filtrarProductos(datos,'MOUSE')).toEqual([datos[0]]));
  it('búsqueda vacía devuelve todos',()=>expect(filtrarProductos(datos,'')).toEqual(datos));
  it('calcula total con cantidades',()=>expect(calcularTotal([{precio:1000,cantidad:2},{precio:500,cantidad:1}])).toBe(2500));
  it('carrito vacío devuelve 0',()=>expect(calcularTotal([])).toBe(0));
});
