import { describe,it,expect } from 'vitest';
import { render,screen,fireEvent } from '@testing-library/react';
import Contador from './Contador.jsx';

describe('Contador',()=>{
  it('parte en cero',()=>{render(<Contador/>);expect(screen.getByRole('button',{name:/contador: 0/i})).toBeInTheDocument();});
  it('incrementa con un click',()=>{render(<Contador/>);fireEvent.click(screen.getByRole('button',{name:/contador: 0/i}));expect(screen.getByRole('button',{name:/contador: 1/i})).toBeInTheDocument();});
});
