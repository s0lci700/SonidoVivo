export default function Producto({ producto, onAgregar }) {
  return <article><h3>{producto.nombre}</h3><p>${producto.precio.toLocaleString('es-CL')}</p><button onClick={()=>onAgregar(producto)}>Agregar</button></article>;
}
