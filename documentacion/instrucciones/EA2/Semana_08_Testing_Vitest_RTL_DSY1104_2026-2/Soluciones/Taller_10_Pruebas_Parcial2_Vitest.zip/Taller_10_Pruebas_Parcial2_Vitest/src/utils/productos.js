export function filtrarProductos(productos,termino){const texto=termino.trim().toLowerCase();if(!texto)return productos;return productos.filter(p=>p.nombre.toLowerCase().includes(texto));}
export function calcularTotal(carrito){return carrito.reduce((suma,item)=>suma+item.precio*item.cantidad,0);}
