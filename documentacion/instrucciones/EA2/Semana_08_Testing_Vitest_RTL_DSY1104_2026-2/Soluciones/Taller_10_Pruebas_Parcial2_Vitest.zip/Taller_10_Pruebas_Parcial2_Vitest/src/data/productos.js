export const productos=[
  {id:1,nombre:'Notebook',precio:599990},
  {id:2,nombre:'Mouse',precio:19990},
  {id:3,nombre:'Teclado',precio:49990}
];
