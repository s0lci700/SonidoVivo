import { useMemo,useState } from 'react';
import { productos } from './data/productos.js';
import { filtrarProductos } from './utils/productos.js';
import Producto from './components/Producto.jsx';
import Buscador from './components/Buscador.jsx';
import Contador from './components/Contador.jsx';
export default function App(){const [busqueda,setBusqueda]=useState('');const [carrito,setCarrito]=useState([]);const visibles=useMemo(()=>filtrarProductos(productos,busqueda),[busqueda]);function agregar(p){setCarrito(a=>[...a,p]);}return <main><h1>Tienda - Semana 08</h1><p>Carrito: {carrito.length}</p><Buscador valor={busqueda} onBuscar={setBusqueda}/><Contador/><section className="grid">{visibles.map(p=><Producto key={p.id} producto={p} onAgregar={agregar}/>)}</section></main>;}
