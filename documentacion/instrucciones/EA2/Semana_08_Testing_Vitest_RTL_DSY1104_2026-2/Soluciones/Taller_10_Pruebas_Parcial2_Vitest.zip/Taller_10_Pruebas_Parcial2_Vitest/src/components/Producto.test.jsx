import { describe,it,expect,vi } from 'vitest';
import { render,screen,fireEvent } from '@testing-library/react';
import Producto from './Producto.jsx';

describe('Producto',()=>{
  it('muestra nombre y precio',()=>{
    const p={id:1,nombre:'Mouse',precio:19990};
    render(<Producto producto={p} onAgregar={()=>{}}/>);
    expect(screen.getByRole('heading',{name:'Mouse'})).toBeInTheDocument();
    expect(screen.getByText('$19.990')).toBeInTheDocument();
  });
  it('llama al callback con el producto',()=>{
    const p={id:1,nombre:'Mouse',precio:19990}; const onAgregar=vi.fn();
    render(<Producto producto={p} onAgregar={onAgregar}/>);
    fireEvent.click(screen.getByRole('button',{name:/agregar/i}));
    expect(onAgregar).toHaveBeenCalledWith(p);
  });
});
