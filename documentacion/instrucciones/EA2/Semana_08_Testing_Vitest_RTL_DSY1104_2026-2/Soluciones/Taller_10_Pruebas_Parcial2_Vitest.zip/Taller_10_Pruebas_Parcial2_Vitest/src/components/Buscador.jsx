export default function Buscador({ valor, onBuscar }) {return <input aria-label="buscar" value={valor} onChange={(e)=>onBuscar(e.target.value)} placeholder="Buscar..." />;}
