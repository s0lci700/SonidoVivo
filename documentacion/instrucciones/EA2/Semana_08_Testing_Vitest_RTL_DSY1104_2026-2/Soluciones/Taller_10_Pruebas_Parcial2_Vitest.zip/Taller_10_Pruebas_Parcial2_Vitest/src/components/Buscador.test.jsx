import { describe,it,expect,vi } from 'vitest';
import { render,screen,fireEvent } from '@testing-library/react';
import Buscador from './Buscador.jsx';

describe('Buscador',()=>{
  it('informa el texto ingresado',()=>{
    const onBuscar=vi.fn();
    render(<Buscador valor="" onBuscar={onBuscar}/>);
    fireEvent.change(screen.getByRole('textbox',{name:'buscar'}),{target:{value:'mouse'}});
    expect(onBuscar).toHaveBeenCalledWith('mouse');
  });
});
