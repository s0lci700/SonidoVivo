# Semana 08 - Vitest + React Testing Library

1. `npm install`
2. `npm run dev` para la aplicación.
3. `npm test` para ejecutar una vez.
4. `npm run test:watch` para modo continuo.
5. `npm run test:coverage` para generar cobertura.

Los ejemplos fijan Vitest 4.1.x para compatibilidad con Node 20 + Vite 8.
