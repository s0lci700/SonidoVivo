export default function App() {
  return <main><h1>Semana 08 - Vitest</h1></main>;
}
