import { describe, it, expect } from 'vitest';
import { sumar, restar } from './calculos.js';

describe('calculos', () => {
  it('suma dos números', () => expect(sumar(2,3)).toBe(5));
  it('resta dos números', () => expect(restar(5,3)).toBe(2));
});
