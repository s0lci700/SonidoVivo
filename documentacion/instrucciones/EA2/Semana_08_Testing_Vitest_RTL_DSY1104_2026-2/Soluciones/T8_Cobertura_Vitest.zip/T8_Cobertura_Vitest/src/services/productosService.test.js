import { describe,it,expect,vi } from 'vitest';
import { cargarProductos } from './productosService.js';

describe('cargarProductos',()=>{
  it('usa el cliente simulado y devuelve datos',async()=>{
    const datos=[{id:1,nombre:'Mouse'}];
    const cliente={obtenerProductos:vi.fn().mockResolvedValue(datos)};
    await expect(cargarProductos(cliente)).resolves.toEqual(datos);
    expect(cliente.obtenerProductos).toHaveBeenCalledTimes(1);
  });
  it('propaga un error del servicio',async()=>{
    const cliente={obtenerProductos:vi.fn().mockRejectedValue(new Error('Sin conexión'))};
    await expect(cargarProductos(cliente)).rejects.toThrow('Sin conexión');
  });
});
