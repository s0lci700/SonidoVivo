import Producto from './components/Producto.jsx';
import Contador from './components/Contador.jsx';
import Buscador from './components/Buscador.jsx';
export default function App(){const p={id:1,nombre:'Mouse',precio:19990};return <main><h1>Componentes</h1><Buscador valor="" onBuscar={()=>{}}/><Contador/><Producto producto={p} onAgregar={()=>{}}/></main>;}
